import.java.sql*;
public class delete{
    public static void main(args[]){
Connection connect = null;
Statement s = null;

try {
	Class.forName("org.mariadb.jdbc.Driver");
	
	connect =  DriverManager.getConnection("jdbc:mariadb://localhost/mydatabase" +
			"?user=root&password=root");
	
	s = connect.createStatement();
	
	String sql = "DELETE FROM customer " +
			" WHERE CustomerID = 'C005' ";
           s.execute(sql);
          
           out.println("Record Delete Successfully");

} catch (Exception e) {
	// TODO Auto-generated catch block
	out.println(e.getMessage());
	e.printStackTrace();
}

try {
	if(s != null) {
		s.close();
		connect.close();
	}
} catch (SQLException e) {
	// TODO Auto-generated catch block
	out.println(e.getMessage());
	e.printStackTrace();
}
    }
}