package myminipro;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author amir
 */
public class NewClass {

    public static void main(String args[]){  
    Connection connect=null;
    try{
      
        connect=DriverManager.getConnection("jdbc:mariadb://localhost:3306/club?user=amir&password=ASyafiq97@");
        Statement stmt=connect.createStatement();
        ResultSet rs= stmt.executeQuery("SELECT * FROM club_member");
        System.out.println("hello");
        while (rs.next())
        System.out.println(rs.getInt("student_id")+"  "+rs.getString("student_name")+"  "+rs.getInt("student_age")+"  "+rs.getString("student_class"));
        
        
        
    } catch(Exception e)
    {
        System.out.println(e);
    }
}
}