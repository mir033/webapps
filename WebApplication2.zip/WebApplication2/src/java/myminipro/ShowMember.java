package myminipro;

import java.sql.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author amir
 */
public class ShowMember {
    
    public static void main(String args[]){  
    Connection connect=null;
    String name;
    String cname;
    int id;
    int age;
    
    try{
      
        connect=DriverManager.getConnection("jdbc:mariadb://localhost:3306/club?user=amir&password=ASyafiq97@");
        Statement stmt=connect.createStatement();
        ResultSet rs= stmt.executeQuery("SELECT * FROM club_member;");
        System.out.println("hello");
        while (rs.next())
        {
            name=rs.getString("student_name");
            cname=rs.getString("student_class");
            id=rs.getInt("student_id");
            age=rs.getInt("student_age");
            System.out.println(name+cname+id+age);
            
        }
        
        
        
    } catch(Exception e)
    {
        System.out.println(e);
    }
    
}
}