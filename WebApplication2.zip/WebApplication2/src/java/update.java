 
Connection connect = null;
Statement s = null;

try {
	Class.forName("org.mariadb.jdbc.Driver");
	
	connect =  DriverManager.getConnection("jdbc:mariadb://localhost/mydatabase" +
			"?user=root&password=root");
	
	s = connect.createStatement();
	
	String sql = "INSERT INTO customer " +
			"(CustomerID,Name,Email,CountryCode,Budget,Used) " + 
			"VALUES ('C005','Chai Surachai','chai.surachai@thaicreate.com'" +
			",'TH','1000000','0') ";
           s.execute(sql);
          
           out.println("Record Inserted Successfully");
           
} catch (Exception e) {
	// TODO Auto-generated catch block
	out.println(e.getMessage());
	e.printStackTrace();
}

try {
	if(s != null) {
		s.close();
		connect.close();
	}
} catch (SQLException e) {
	// TODO Auto-generated catch block
	out.println(e.getMessage());
	e.printStackTrace();
}
